"use client"

import type React from "react"
import Image from "next/image"
import type { ReactNode } from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
// Add the Info icon import at the top with the other icon imports
import { Shield, MessageSquare, Clock, ChevronRight, Key, UserCog, Info } from "lucide-react"
import { Toaster } from "sonner"
import { toast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"

// Add these imports at the top
import { ThemeToggle } from "@/components/theme-toggle"
import { UISettings } from "@/components/ui-settings"

// Define a type for saved conversations
interface SavedConversation {
  id: string
  title: string
  date: Date
  messages: any[] // In a real app, you would use a more specific type
  preview: string
}

export default function ClientLayout({ children }: { children: ReactNode }) {
  const [hasConversation, setHasConversation] = useState(false)
  const [showAdminLogin, setShowAdminLogin] = useState(false)
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false)
  const [passwordError, setPasswordError] = useState(false)

  // State for saved conversations
  const [savedConversations, setSavedConversations] = useState<SavedConversation[]>([])
  const [activeConversation, setActiveConversation] = useState<string | null>(null)
  const [isNewlySaved, setIsNewlySaved] = useState<string | null>(null)

  // Add this with the other state variables
  const [messageCount, setMessageCount] = useState(0)
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false)

  const [isPremiumKeyDialogOpen, setIsPremiumKeyDialogOpen] = useState(false)
  const [premiumKey, setPremiumKey] = useState("")
  const [isPremiumUser, setIsPremiumUser] = useState(false)
  const [premiumKeyError, setPremiumKeyError] = useState(false)

  // Add state for generated premium key
  const [generatedKey, setGeneratedKey] = useState("")
  const [showGeneratedKeyDialog, setShowGeneratedKeyDialog] = useState(false)

  // Add the About Us dialog state after the other state variables
  const [isAboutUsDialogOpen, setIsAboutUsDialogOpen] = useState(false)

  // Function to handle saving conversation
  const handleSaveConversation = () => {
    // Check if there's an active conversation (this is a simplified check)
    // In a real implementation, you would check if there are actual messages
    if (hasConversation) {
      // Check if user has reached message limit
      if (messageCount >= 5) {
        setShowUpgradePrompt(true)
        toast({
          title: "Free plan limit reached",
          description: "You've reached the message limit. Please upgrade to save conversations.",
          variant: "destructive",
        })
        return
      }

      // Generate a unique ID for the conversation
      const conversationId = `conv-${Date.now()}`

      // Create a new saved conversation
      const newConversation: SavedConversation = {
        id: conversationId,
        title: `Conversation ${savedConversations.length + 1}`,
        date: new Date(),
        messages: [], // In a real app, you would store the actual messages
        preview: "This is a sample conversation with InfinityAI...",
      }

      // Add the new conversation to the saved conversations list
      setSavedConversations((prev) => [newConversation, ...prev])

      // Set the newly saved conversation flag to highlight it
      setIsNewlySaved(conversationId)

      // Clear the highlight after 3 seconds
      setTimeout(() => {
        setIsNewlySaved(null)
      }, 3000)

      // Save the conversation (in a real app, this would store the messages)
      toast({
        title: "Success",
        description: "Conversation saved! You can view it in chat history.",
      })
    } else {
      // No conversation to save
      toast({
        title: "No conversation found",
        description: "Start a chat with InfinityAI first.",
        variant: "destructive",
      })
    }
  }

  // Add this function to check message limits
  const checkMessageLimit = () => {
    // Premium users have no message limits
    if (isPremiumUser) {
      return true
    }

    // For demo purposes, we're using a simple counter
    // In a real app, this would be stored in a database or localStorage
    if (messageCount >= 5) {
      setShowUpgradePrompt(true)
      toast({
        title: "Message limit reached",
        description: "You've reached the free plan limit. Please upgrade to continue.",
        variant: "destructive",
      })
      return false
    }

    setMessageCount((prev) => prev + 1)
    return true
  }

  // For demo purposes, let's toggle the hasConversation state when the component mounts
  // In a real app, this would be determined by checking if there are messages
  useEffect(() => {
    // This is just for demonstration - you would replace this with actual logic
    // to check if there are messages in the conversation
    const checkForMessages = () => {
      // Example: Check if there are messages in the conversation
      // const messages = getMessages();
      // setHasConversation(messages.length > 0);

      // For demo, we'll just set it based on a timeout
      setTimeout(() => {
        setHasConversation(true)
      }, 5000) // After 5 seconds, pretend there's a conversation
    }

    checkForMessages()
  }, [])

  // Handle admin panel access
  const handleAdminAccess = () => {
    setIsPasswordDialogOpen(true)
  }

  // Handle admin password submission
  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Check if password is correct - now using "123" as the password
    if (adminPassword === "123") {
      setIsPasswordDialogOpen(false)
      setPasswordError(false)
      setAdminPassword("")

      // Generate a premium key
      const timestamp = Date.now().toString(36).toUpperCase()
      const randomStr = Math.random().toString(36).substring(2, 6).toUpperCase()
      const newKey = `PREMIUM-${timestamp.substring(0, 4)}-${randomStr}-${timestamp.substring(4, 8)}`

      setGeneratedKey(newKey)
      setShowGeneratedKeyDialog(true)

      toast({
        title: "Premium Key Generated",
        description: "A new premium key has been generated for you.",
      })
    } else {
      setPasswordError(true)
      toast({
        title: "Access Denied",
        description: "Incorrect admin password.",
        variant: "destructive",
      })
    }
  }

  // Format date for display
  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // Handle clicking on a saved conversation
  const handleConversationClick = (conversationId: string) => {
    setActiveConversation(conversationId)
    // In a real app, you would load the conversation messages here
    toast({
      description: `Loading conversation ${conversationId}...`,
    })
  }

  // Add this right before the return statement
  useEffect(() => {
    // Reset message count when component mounts
    setMessageCount(0)
  }, [])

  // Add this right before the return statement
  const handleUpgradeClose = () => {
    setShowUpgradePrompt(false)
  }

  const handlePremiumKeySubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // In a real app, you would validate this key against a database
    // For demo purposes, we'll accept any key that starts with "PREMIUM-"
    if (premiumKey.startsWith("PREMIUM-")) {
      setIsPremiumUser(true)
      setIsPremiumKeyDialogOpen(false)
      setPremiumKeyError(false)
      setPremiumKey("")

      toast({
        title: "Premium Access Granted",
        description: "You now have unlimited access to InfinityAI!",
      })
    } else {
      setPremiumKeyError(true)
      toast({
        title: "Invalid Key",
        description: "The premium key you entered is not valid.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-64 border-r bg-[#1a1a2e]/95 backdrop-blur-sm ios-blur">
        <div className="p-4 border-b border-gray-800 bg-[#1a1a2e]/80 backdrop-blur-md">
          <div className="flex items-center justify-center mb-2">
            <Image
              src="/images/infinity-ai-logo.png"
              alt="InfinityAI Logo"
              width={180}
              height={50}
              className="h-auto"
            />
          </div>
          {isPremiumUser && (
            <div className="mt-2 flex items-center gap-1.5 text-xs bg-amber-900/30 text-amber-300 px-2 py-1 rounded-full border border-amber-700/50">
              <Shield className="h-3 w-3 text-amber-400" />
              <span className="font-medium">Premium Access Enabled</span>
            </div>
          )}
        </div>
        <ScrollArea className="h-[calc(100vh-88px)] text-gray-300">
          <div className="space-y-4 p-4">
            {/* Premium Plans Section */}
            <div>
              <h3 className="mb-2 px-2 text-sm font-medium text-gray-400 flex items-center">
                <Shield className="h-3.5 w-3.5 mr-1.5 text-yellow-500" />
                Premium Access
              </h3>
              <div className="space-y-2">
                {/* Free Plan */}
                <div className="p-2 rounded-lg border border-gray-700 bg-gray-800/50 ios-transition">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="text-sm font-medium flex items-center text-gray-300">
                      <span className="h-2 w-2 rounded-full bg-gray-400 mr-1.5"></span>
                      Free Plan
                    </h4>
                    <span className="text-xs font-bold bg-gray-700 px-2 py-0.5 rounded-full">₹0</span>
                  </div>
                  <p className="text-xs text-gray-400 mb-1">Limited access to InfinityAI</p>
                  <ul className="text-xs text-gray-400 space-y-1 mt-2">
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> 5 messages per day
                    </li>
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Basic responses
                    </li>
                    <li className="flex items-center">
                      <span className="text-red-500 mr-1">✗</span> No conversation history
                    </li>
                  </ul>
                </div>

                {/* Pro Plan */}
                <div className="p-2 rounded-lg border border-blue-900/50 bg-blue-900/20 ios-transition">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="text-sm font-medium flex items-center text-gray-300">
                      <span className="h-2 w-2 rounded-full bg-blue-500 mr-1.5"></span>
                      Pro Plan
                    </h4>
                    <span className="text-xs font-bold bg-blue-900/50 px-2 py-0.5 rounded-full">₹30/month</span>
                  </div>
                  <p className="text-xs text-gray-400 mb-1">Enhanced access to InfinityAI</p>
                  <ul className="text-xs text-gray-400 space-y-1 mt-2">
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> 100 messages per day
                    </li>
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Advanced responses
                    </li>
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Save up to 10 conversations
                    </li>
                  </ul>
                </div>

                {/* Legend Plan */}
                <div className="p-2 rounded-lg border border-purple-900/50 bg-purple-900/20 ios-transition">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="text-sm font-medium flex items-center text-gray-300">
                      <span className="h-2 w-2 rounded-full bg-purple-500 mr-1.5"></span>
                      Legend Plan
                    </h4>
                    <span className="text-xs font-bold bg-purple-900/50 px-2 py-0.5 rounded-full">₹100/month</span>
                  </div>
                  <p className="text-xs text-gray-400 mb-1">Premium access to InfinityAI</p>
                  <ul className="text-xs text-gray-400 space-y-1 mt-2">
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Unlimited messages
                    </li>
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Priority processing
                    </li>
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Save unlimited conversations
                    </li>
                  </ul>
                </div>

                {/* Ultimate Pro Plan */}
                <div className="p-2 rounded-lg border border-amber-900/50 bg-amber-900/20 ios-transition">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="text-sm font-medium flex items-center text-gray-300">
                      <span className="h-2 w-2 rounded-full bg-amber-500 mr-1.5"></span>
                      Ultimate Pro Plan
                    </h4>
                    <span className="text-xs font-bold bg-amber-900/50 px-2 py-0.5 rounded-full">₹1000/month</span>
                  </div>
                  <p className="text-xs text-gray-400 mb-1">Enterprise-grade InfinityAI</p>
                  <ul className="text-xs text-gray-400 space-y-1 mt-2">
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Unlimited everything
                    </li>
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Dedicated support
                    </li>
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> Custom model training
                    </li>
                    <li className="flex items-center">
                      <span className="text-green-500 mr-1">✓</span> API access
                    </li>
                  </ul>
                </div>

                {/* Upgrade Button */}
                <Button
                  className="w-full mt-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white ios-glow"
                  onClick={() => {
                    toast({
                      title: "Redirecting to Telegram",
                      description: "Contact @PRAKHAR_VARDHAN on Telegram to upgrade your plan",
                    })
                    // Open Telegram in a new tab
                    window.open("https://t.me/PRAKHAR_VARDHAN", "_blank")
                  }}
                >
                  Upgrade Your Plan
                </Button>

                {/* Premium Key Button */}
                <Button
                  variant="outline"
                  className="w-full mt-2 border-dashed border-blue-500/50 text-blue-400 hover:bg-blue-900/20 ios-transition"
                  onClick={() => setIsPremiumKeyDialogOpen(true)}
                >
                  <Key className="h-4 w-4 mr-2" />
                  Enter Premium Key
                </Button>
              </div>
            </div>

            {/* Divider */}
            <div className="border-t border-gray-800 pt-4"></div>

            {/* Chat History Section */}
            <div>
              <h3 className="mb-2 px-2 text-sm font-medium text-gray-400 flex items-center">
                <Clock className="h-3.5 w-3.5 mr-1.5" />
                Chat History
              </h3>
              <div className="space-y-2">
                {savedConversations.length === 0 ? (
                  // Empty state - no saved conversations yet
                  <div className="px-2 py-3 text-center text-sm text-gray-400 border border-dashed border-gray-700 rounded-md ios-transition hover:border-blue-500/30 hover:bg-gray-800/50">
                    <MessageSquare className="h-4 w-4 mx-auto mb-1 opacity-50 ios-icon" />
                    <p>No saved conversations yet</p>
                    <p className="text-xs mt-1">Click "Save conversation" to add one</p>
                  </div>
                ) : (
                  // Display saved conversations
                  savedConversations.map((conversation) => (
                    <div
                      key={conversation.id}
                      className={`p-2 rounded-lg cursor-pointer transition-all duration-300 ios-button ${
                        isNewlySaved === conversation.id
                          ? "bg-blue-900/30 border border-blue-700/50 animate-pulse"
                          : activeConversation === conversation.id
                            ? "bg-gray-800 border border-gray-700"
                            : "hover:bg-gray-800/70 border border-transparent"
                      }`}
                      onClick={() => handleConversationClick(conversation.id)}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="text-sm font-medium truncate text-gray-300">{conversation.title}</h4>
                        <span className="text-xs text-gray-500">{formatDate(conversation.date)}</span>
                      </div>
                      <p className="text-xs text-gray-400 truncate">{conversation.preview}</p>
                      <div className="flex justify-end mt-1">
                        <ChevronRight className="h-3.5 w-3.5 text-gray-500" />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Divider */}
            <div className="border-t border-gray-800 pt-4"></div>

            {/* About Us Button */}
            <div className="flex justify-center mb-4">
              <Button
                variant="outline"
                size="sm"
                className="ios-button rounded-full p-2 h-10 w-10 border-dashed border-blue-500/50 hover:bg-blue-900/30 text-blue-400"
                onClick={() => setIsAboutUsDialogOpen(true)}
                title="About Us"
              >
                <Info className="h-5 w-5" />
              </Button>
            </div>

            {/* Admin Button */}
            <div className="flex justify-center">
              <Button
                variant="outline"
                size="sm"
                className="ios-button rounded-full p-2 h-10 w-10 border-dashed border-amber-500/50 hover:bg-amber-900/30 text-amber-400"
                onClick={handleAdminAccess}
                title="Admin Access"
              >
                <UserCog className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </ScrollArea>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <header className="h-14 border-b px-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="ios-button rounded-lg" onClick={handleSaveConversation}>
                Save conversation
              </Button>
            </div>

            {/* Add this new div for the right side controls */}
            <div className="flex items-center gap-2">
              <UISettings />
              <ThemeToggle />
            </div>
          </header>
          {children}
        </div>
      </div>

      {/* Admin Password Dialog */}
      <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserCog className="h-5 w-5 text-amber-500" />
              Admin Access
            </DialogTitle>
            <DialogDescription>Enter the admin password to generate a premium key.</DialogDescription>
          </DialogHeader>

          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <div className="space-y-2">
              <Input
                type="password"
                placeholder="Enter admin password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className={passwordError ? "border-red-500" : ""}
                autoFocus
              />
              {passwordError && <p className="text-xs text-red-500">Incorrect password. Please try again.</p>}
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                className="ios-button"
                onClick={() => setIsPasswordDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" className="ios-button ios-glow bg-amber-500 hover:bg-amber-600 text-white">
                Generate Premium Key
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Generated Key Dialog */}
      <Dialog open={showGeneratedKeyDialog} onOpenChange={setShowGeneratedKeyDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Key className="h-5 w-5 text-green-500" />
              Premium Key Generated
            </DialogTitle>
            <DialogDescription>
              Your premium key has been generated. Copy this key and use it to activate premium features.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="p-3 bg-gray-50 rounded-md border font-mono text-center text-sm break-all">
              {generatedKey}
            </div>
            <p className="text-xs text-muted-foreground">
              This key provides unlimited access to InfinityAI. Keep it secure and do not share it with others.
            </p>
          </div>

          <DialogFooter>
            <Button
              className="ios-button ios-glow bg-green-500 hover:bg-green-600 text-white"
              onClick={() => {
                navigator.clipboard.writeText(generatedKey)
                toast({
                  title: "Copied to Clipboard",
                  description: "Premium key has been copied to your clipboard.",
                })
              }}
            >
              Copy Key
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Upgrade Plan Dialog */}
      <Dialog open={showUpgradePrompt} onOpenChange={setShowUpgradePrompt}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-yellow-500" />
              Upgrade Your Plan
            </DialogTitle>
            <DialogDescription>
              You've reached the limit of 5 messages on the Free Plan. Upgrade to continue chatting with InfinityAI.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 rounded-lg border border-blue-200 bg-blue-50">
                <div>
                  <h4 className="font-medium">Pro Plan</h4>
                  <p className="text-sm text-muted-foreground">100 messages/day + more features</p>
                </div>
                <span className="font-bold">₹30/month</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-purple-200 bg-purple-50">
                <div>
                  <h4 className="font-medium">Legend Plan</h4>
                  <p className="text-sm text-muted-foreground">Unlimited messages + priority</p>
                </div>
                <span className="font-bold">₹100/month</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-amber-200 bg-amber-50">
                <div>
                  <h4 className="font-medium">Ultimate Pro</h4>
                  <p className="text-sm text-muted-foreground">Enterprise features + API access</p>
                </div>
                <span className="font-bold">₹1000/month</span>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={handleUpgradeClose}>
              Maybe Later
            </Button>
            <Button
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white"
              onClick={() => {
                toast({
                  title: "Contact Admin",
                  description: "Please contact admin to upgrade your plan",
                })
                handleUpgradeClose()
              }}
            >
              Upgrade Now
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Premium Key Dialog */}
      <Dialog open={isPremiumKeyDialogOpen} onOpenChange={setIsPremiumKeyDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Key className="h-5 w-5 text-primary" />
              Enter Premium Key
            </DialogTitle>
            <DialogDescription>Enter your premium key to unlock unlimited access to InfinityAI.</DialogDescription>
          </DialogHeader>

          <form onSubmit={handlePremiumKeySubmit} className="space-y-4">
            <div className="space-y-2">
              <Input
                type="text"
                placeholder="PREMIUM-XXXX-XXXX-XXXX"
                value={premiumKey}
                onChange={(e) => setPremiumKey(e.target.value)}
                className={premiumKeyError ? "border-red-500" : ""}
                autoFocus
              />
              {premiumKeyError && (
                <p className="text-xs text-red-500">Invalid premium key. Please check and try again.</p>
              )}
              <p className="text-xs text-muted-foreground">
                Premium keys are generated by administrators and provide unlimited access to all features.
              </p>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                className="ios-button"
                onClick={() => setIsPremiumKeyDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" className="ios-button ios-glow bg-primary hover:bg-primary/90">
                Activate Premium
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* About Us Dialog */}
      <Dialog open={isAboutUsDialogOpen} onOpenChange={setIsAboutUsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <Image
                src="/images/infinity-ai-logo.png"
                alt="InfinityAI Logo"
                width={120}
                height={30}
                className="h-auto"
              />
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2 max-h-[70vh] overflow-y-auto pr-2">
            <p className="text-sm">
              Welcome to Infinity AI, where innovation meets conversation! 🚀 We specialize in building cutting-edge AI
              chatbots designed to enhance communication and provide intelligent, real-time interactions.
            </p>

            <div className="space-y-2">
              <h3 className="font-semibold text-base">Who We Are</h3>
              <p className="text-sm">
                I am Prakhar Vardhan, a passionate developer currently studying in Class 10. With expertise in AI,
                chatbot development, and software engineering, I aim to create powerful AI solutions that redefine
                digital conversations.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-base">Our Mission</h3>
              <p className="text-sm">
                At Infinity AI, our goal is to revolutionize online interactions by making AI more accessible,
                intelligent, and human-like. We strive to develop AI chatbots that can assist, entertain, and engage
                users effortlessly.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-base">Our Vision</h3>
              <p className="text-sm">
                To become a leading platform for AI-powered conversations, where users can experience seamless,
                intuitive, and natural interactions with AI chatbots.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-base">What We Offer</h3>
              <ul className="text-sm space-y-1 list-none">
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✅</span> AI-Powered Chatbots for Businesses & Individuals
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✅</span> Smart Conversational AI for Websites & Apps
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✅</span> Custom AI Assistants for Telegram & Web Integration
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✅</span> 24/7 Support & Continuous Improvements
                </li>
              </ul>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-base">Connect With Us</h3>
              <ul className="text-sm space-y-1 list-none">
                <li className="flex items-start">
                  <span className="text-blue-500 mr-2">📩</span> Contact: Always open to collaboration and innovation!
                </li>
                <li className="flex items-start">
                  <span className="text-blue-500 mr-2">📌</span> Telegram:
                  <a
                    href="https://t.me/PRAKHAR_VARDHAN"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline ml-1"
                  >
                    @PRAKHAR_VARDHAN
                  </a>
                </li>
              </ul>
            </div>

            <p className="text-sm font-medium text-center pt-2">
              Join us in shaping the future of AI-powered communication!
            </p>

            <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <h4 className="font-semibold text-sm">FOUNDER</h4>
                  <p className="text-sm">PRAKHAR VARDHAN</p>
                </div>
                <div className="text-center">
                  <h4 className="font-semibold text-sm">CEO</h4>
                  <p className="text-sm">SAIDUR RAHEMAN</p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              className="ios-button ios-glow bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
              onClick={() => setIsAboutUsDialogOpen(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Toast notifications */}
      <Toaster position="top-right" />
    </div>
  )
}


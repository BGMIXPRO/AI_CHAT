"use server"

import { cookies } from "next/headers"
import { encrypt } from "@/lib/encryption"

export async function saveApiKey(apiKey: string) {
  try {
    console.log("Attempting to validate API key...")

    // Validate the API key by making a test request
    await validateApiKey(apiKey)

    console.log("API key validation successful")

    // Encrypt the API key before storing
    const encryptedKey = await encrypt(apiKey)

    // Store in a HTTP-only cookie (secure in production)
    cookies().set("infinity_api_key", encryptedKey, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 30 * 24 * 60 * 60, // 30 days
      path: "/",
    })

    return { success: true }
  } catch (error: any) {
    console.error("Error saving API key:", error)
    return {
      success: false,
      error: error.message || "Failed to save API key. Please try again.",
    }
  }
}

export async function checkApiKeyExists() {
  const apiKeyCookie = cookies().get("infinity_api_key")
  return { exists: !!apiKeyCookie }
}

export async function clearApiKey() {
  cookies().delete("infinity_api_key")
  return { success: true }
}

async function validateApiKey(apiKey: string) {
  try {
    // First, check if the API key has a valid format (basic check)
    if (!apiKey || apiKey.trim().length < 10) {
      throw new Error("API key appears to be too short or invalid")
    }

    // Make a simple request to validate the API key with better error handling
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: "Hello" }],
            },
          ],
          generationConfig: {
            maxOutputTokens: 5,
          },
        }),
      },
    )

    // If we get a 400 error, it might be content-related but the API key could still be valid
    if (response.status === 400) {
      const errorData = await response.json()
      console.log("API returned 400 error, checking error type:", errorData)

      // If the error is about invalid API key, throw an error
      if (errorData.error?.message?.includes("API key")) {
        throw new Error(errorData.error.message || "Invalid API key")
      }

      // Otherwise, assume the key is valid but there was another issue with the request
      console.log("API key appears valid, but request had other issues")
      return true
    }

    if (!response.ok) {
      const errorData = await response.json()
      console.error("API validation error:", errorData)
      throw new Error(errorData.error?.message || "Invalid API key")
    }

    return true
  } catch (error: any) {
    console.error("API key validation error:", error)

    // For development/testing purposes, you can bypass validation
    // by uncommenting the next line (ONLY FOR DEVELOPMENT)
    // return true;

    throw new Error(error.message || "Invalid API key. Please check and try again.")
  }
}


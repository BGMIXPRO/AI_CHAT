import { cookies } from "next/headers"
import { decrypt } from "@/lib/encryption"
import { StreamingTextResponse } from "ai"

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

export async function POST(req: Request) {
  try {
    // Parse the request body
    const body = await req.json()
    const messages = body.messages || []

    // Get the API key from cookies
    const cookieStore = cookies()
    const encryptedApiKey = cookieStore.get("infinity_api_key")?.value

    if (!encryptedApiKey) {
      return Response.json(
        { error: "No API key found. Please add your InfinityAI API key in settings." }, 
        { status: 401 }
      )
    }

    // Decrypt the API key
    let apiKey
    try {
      apiKey = await decrypt(encryptedApiKey)
    } catch (error) {
      console.error("API key decryption error:", error)
      return Response.json(
        { error: "Failed to decrypt API key. Please add your API key again." }, 
        { status: 401 }
      )
    }

    // Add a basic validation check for the API key format
    if (!apiKey || apiKey.trim().length < 10) {
      return Response.json(
        { error: "Invalid API key format. Please add a valid API key in settings." }, 
        { status: 401 }
      )
    }

    // Format messages for Gemini API
    const formattedMessages = messages.map((message) => ({
      role: message.role === "user" ? "user" : "model",
      parts: [{ text: message.content }],
    }))

    // Create a ReadableStream to handle the response
    const stream = new ReadableStream({
      async start(controller) {
        // Function to send error messages to the client
        const sendError = (message) => {
          const encoder = new TextEncoder()
          controller.enqueue(encoder.encode(`Error: ${message}`))
          controller.close()
        }

        try {
          // Make a direct fetch request to Gemini API
          const response = await fetch(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:streamGenerateContent",
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "x-goog-api-key": apiKey,
              },
              body: JSON.stringify({
                contents: formattedMessages,
                generationConfig: {
                  maxOutputTokens: 1024,
                  temperature: 0.7,
                  topP: 0.95,
                },
                safetySettings: [
                  {
                    category: "HARM_CATEGORY_HARASSMENT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE",
                  },
                  {
                    category: "HARM_CATEGORY_HATE_SPEECH",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE",
                  },
                  {
                    category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE",
                  },
                  {
                    category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE",
                  },
                ],
              }),
            },
          )

          // Check if the response is successful
          if (!response.ok) {
            let errorMessage = "Failed to communicate with Gemini API"
            try {
              const errorData = await response.json()
              errorMessage = errorData.error?.message || errorMessage
              console.error("Gemini API error:", errorData)
            } catch (e) {
              console.error("Failed to parse error response:", e)
            }

            // Handle specific error cases
            if (response.status === 400) {
              // Check if it's an API key issue or content policy issue
              if (errorMessage.includes("API key")) {
                sendError("Invalid API key. Please check your InfinityAI API key.")
              } else {
                sendError("Invalid request to Gemini API. This might be due to content policy violations.")
              }
              return
            } else if (response.status === 401 || response.status === 403) {
              sendError("Authentication failed. Please check your InfinityAI API key.")
              return
            } else if (response.status === 429) {
              sendError("Rate limit exceeded. Please try again later.")
              return
            } else {
              sendError(`InfinityAI API error: ${errorMessage}`)
              return
            }
          }

          // Process the response stream
          const reader = response.body?.getReader();
          if (!reader) {
            sendError("Failed to get response reader");
            return;
          }

          const encoder = new TextEncoder();
          const decoder = new TextDecoder();
          let buffer = '';

          // Function to extract complete JSON objects from the buffer
          const extractCompleteJSON = (text) => {
            const objects = [];
            let startPos = 0;
            let openBraces = 0;
            let inString = false;
            let escapeNext = false;
            
            for (let i = 0; i < text.length; i++) {
              const char = text[i];
              
              if (escapeNext) {
                escapeNext = false;
                continue;
              }
              
              if (char === '\\' && inString) {
                escapeNext = true;
                continue;
              }
              
              if (char === '"' && !escapeNext) {
                inString = !inString;
                continue;
              }
              
              if (!inString) {
                if (char === '{') {
                  if (openBraces === 0) {
                    startPos = i;
                  }
                  openBraces++;
                } else if (char === '}') {
                  openBraces--;
                  if (openBraces === 0) {
                    // We found a complete JSON object
                    objects.push(text.substring(startPos, i + 1));
                  }
                }
              }
            }
            
            // Return the remaining incomplete part
            const lastPos = objects.length > 0 ? 
              startPos + objects[objects.length - 1].length : 
              0;
              
            return {
              objects,
              remaining: text.substring(lastPos)
            };
          };

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            // Convert the chunk to text
            const chunk = decoder.decode(value, { stream: true });
            buffer += chunk;
            
            // Extract complete JSON objects
            const { objects, remaining } = extractCompleteJSON(buffer);
            buffer = remaining;
            
            // Process each complete JSON object
            for (const jsonStr of objects) {
              try {
                const data = JSON.parse(jsonStr);
                
                // Extract text from the response
                if (data.candidates && data.candidates[0]?.content?.parts) {
                  const text = data.candidates[0].content.parts[0]?.text || '';
                  if (text) {
                    controller.enqueue(encoder.encode(text));
                  }
                }
              } catch (e) {
                console.error("Error parsing JSON:", e, "Object:", jsonStr);
                // Continue processing other objects even if one fails
              }
            }
          }

          // Try to process any remaining data in the buffer
          // This is a best-effort attempt and might not work if the buffer is incomplete
          if (buffer.trim()) {
            try {
              // Try to find any valid JSON in the remaining buffer
              if (buffer.includes('{') && buffer.includes('}')) {
                const startIdx = buffer.indexOf('{');
                const endIdx = buffer.lastIndexOf('}') + 1;
                if (startIdx < endIdx) {
                  const jsonStr = buffer.substring(startIdx, endIdx);
                  const data = JSON.parse(jsonStr);
                  
                  if (data.candidates && data.candidates[0]?.content?.parts) {
                    const text = data.candidates[0].content.parts[0]?.text || '';
                    if (text) {
                      controller.enqueue(encoder.encode(text));
                    }
                  }
                }
              }
            } catch (e) {
              console.error("Error parsing final JSON chunk:", e);
            }
          }

          controller.close();\
      },
    })

    // Return the streaming response
    return new StreamingTextResponse(stream)
  } catch (error) {
    console.error("Chat API error:", error)

    return Response.json({ error: error.message || "An unexpected error occurred" }, { status: 500 })
  }
}


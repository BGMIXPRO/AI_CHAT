"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Copy, Send, AlertCircle, Loader2, RefreshCcw, Key, MessageSquare } from "lucide-react"
import { cn } from "@/lib/utils"
import { type Message, useChat } from "ai/react"
import { ApiKeyStatus } from "@/components/api-key-status"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { checkApiKeyExists } from "@/app/actions"
import { toast } from "@/components/ui/use-toast"

export default function ChatInterface() {
  const [hasApiKey, setHasApiKey] = useState<boolean | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [input, setInput] = useState("")
  const [localMessages, setLocalMessages] = useState<Message[]>([])
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Check if API key exists on component mount
  useEffect(() => {
    const checkKey = async () => {
      try {
        const { exists } = await checkApiKeyExists()
        setHasApiKey(exists)

        // Add welcome message if API key exists
        if (exists) {
          setLocalMessages([
            {
              id: "welcome",
              role: "assistant",
              content: "Hello! I'm your AI assistant powered by InfinityAI. How can I help you today?",
            },
          ])
        }
      } catch (error) {
        console.error("Error checking API key:", error)
        toast({
          title: "Error",
          description: "Failed to check API key status",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    checkKey()
  }, [])

  // Use AI SDK's useChat hook with error handling
  const {
    messages,
    append,
    isLoading: isChatLoading,
    error,
    reload,
    stop,
  } = useChat({
    api: "/api/chat",
    initialMessages: localMessages,
    onResponse: (response) => {
      // Log response details for debugging
      console.log("Chat response received:", {
        status: response.status,
        ok: response.ok,
      })

      // When we start getting a response
      scrollToBottom()
    },
    onError: (error) => {
      console.error("Chat error details:", error)

      toast({
        title: "Error",
        description: error.message || "An error occurred during the conversation",
        variant: "destructive",
      })
    },
    onFinish: () => {
      // When message is complete
      scrollToBottom()
    },
  })

  // Update local messages when messages from useChat change
  useEffect(() => {
    setLocalMessages(messages)
  }, [messages])

  // Scroll to bottom of chat
  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }

  // Auto-scroll when new messages arrive
  useEffect(() => {
    scrollToBottom()
  }, [localMessages])

  // Handle form submission
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim() || !hasApiKey || isChatLoading) return

    try {
      // Store the input and clear it immediately for better UX
      const userInput = input
      setInput("")

      // Add user message to local messages for immediate feedback
      const userMessage: Message = {
        id: Date.now().toString(),
        role: "user",
        content: userInput,
      }

      setLocalMessages((prev) => [...prev, userMessage])

      // Send message to API
      await append({
        role: "user",
        content: userInput,
      })

      // Focus back on textarea after sending
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.focus()
        }
      }, 100)
    } catch (error: any) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Handle stop generation
  const handleStopGeneration = () => {
    stop()
    toast({
      description: "Stopped response generation",
    })
  }

  // Handle retry
  const handleRetry = () => {
    reload()
    toast({
      description: "Retrying last message",
    })
  }

  // Handle clear chat
  const handleClearChat = () => {
    setLocalMessages([
      {
        id: "welcome",
        role: "assistant",
        content: "Hello! I'm your AI assistant powered by InfinityAI. How can I help you today?",
      },
    ])
    toast({
      description: "Chat history cleared",
    })
  }

  // Handle API key update
  const handleApiKeyUpdate = (exists: boolean) => {
    setHasApiKey(exists)
    if (exists && localMessages.length === 0) {
      // Add welcome message when API key is added
      setLocalMessages([
        {
          id: "welcome",
          role: "assistant",
          content: "Hello! I'm your AI assistant powered by InfinityAI. How can I help you today?",
        },
      ])
    }
  }

  // Format timestamp
  const getTimestamp = () => {
    const now = new Date()
    return now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // Handle copy to clipboard
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      description: "Copied to clipboard",
    })
  }

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* API Key Status in Header */}
      <div className="h-14 border-b px-4 flex items-center justify-between">
        <h1 className="text-sm font-medium">AI Chat</h1>
        <div className="flex items-center gap-2">
          {localMessages.length > 1 && (
            <Button variant="ghost" size="sm" onClick={handleClearChat} disabled={isChatLoading}>
              Clear Chat
            </Button>
          )}
          <ApiKeyStatus onSuccess={handleApiKeyUpdate} />
        </div>
      </div>

      {/* Chat Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        <div className="space-y-4 pb-4">
          {!isLoading && !hasApiKey && (
            <div className="flex flex-col items-center justify-center text-center p-8 rounded-lg border border-dashed">
              <div className="mb-4 rounded-full bg-muted p-3">
                <Key className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-1">Welcome to InfinityAI Chat</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                Please add your InfinityAI API key to start chatting
              </p>
            </div>
          )}

          {!isLoading && hasApiKey && localMessages.length === 0 && (
            <div className="flex flex-col items-center justify-center text-center p-8 rounded-lg border border-dashed">
              <div className="mb-4 rounded-full bg-muted p-3">
                <MessageSquare className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-1">Start a conversation</h3>
              <p className="text-sm text-muted-foreground max-w-sm">Send a message to begin chatting with InfinityAI</p>
            </div>
          )}

          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="flex items-center gap-2">
                {error.message || "An error occurred. Please try again."}
                <Button variant="outline" size="sm" onClick={handleRetry}>
                  <RefreshCcw className="h-3 w-3 mr-1" />
                  Retry
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {localMessages.map((message, index) => (
            <div
              key={message.id || index}
              className={cn("flex gap-3 max-w-[85%]", message.role === "user" ? "ml-auto flex-row-reverse" : "")}
            >
              {message.role !== "user" && (
                <div className="h-8 w-8 rounded-full bg-primary flex-shrink-0 flex items-center justify-center text-primary-foreground font-semibold">
                  I
                </div>
              )}

              {message.role === "user" && (
                <div className="h-8 w-8 rounded-full bg-muted flex-shrink-0 flex items-center justify-center">U</div>
              )}

              <div className={cn("space-y-2", message.role === "user" ? "items-end" : "")}>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{message.role === "user" ? "You" : "InfinityAI"}</span>
                  <span className="text-xs text-muted-foreground">{getTimestamp()}</span>
                </div>

                <div
                  className={cn(
                    "p-3 rounded-lg",
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted",
                  )}
                >
                  <div className="text-sm whitespace-pre-wrap">{message.content}</div>
                </div>

                {message.role !== "user" && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => handleCopy(message.content)}
                      title="Copy to clipboard"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isChatLoading && (
            <div className="flex items-center justify-center py-4">
              <div className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
                <span className="text-sm text-muted-foreground">InfinityAI is thinking...</span>
                <Button variant="outline" size="sm" onClick={handleStopGeneration} className="ml-2">
                  Stop
                </Button>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-4 border-t bg-background mt-auto">
        <form onSubmit={handleFormSubmit} className="relative">
          <div className="relative flex items-center">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  if (input.trim() && !isLoading && !isChatLoading) {
                    handleFormSubmit(e)
                  }
                }
              }}
              placeholder={hasApiKey ? "Type your message..." : "Add InfinityAI API key to start chatting"}
              disabled={!hasApiKey || isChatLoading}
              className="flex-1 resize-none border rounded-md py-3 px-4 focus-visible:ring-1 focus-visible:ring-ring min-h-[44px] max-h-32 pr-10"
              rows={1}
            />
            <Button
              type="submit"
              className="absolute right-1.5 bottom-1.5"
              size="sm"
              disabled={!hasApiKey || isChatLoading || !input.trim()}
            >
              {isChatLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
          <div className="text-xs text-muted-foreground mt-1 text-right">
            Press <kbd className="px-1 py-0.5 bg-muted rounded border">Enter</kbd> to send,
            <kbd className="px-1 py-0.5 bg-muted rounded border ml-1">Shift + Enter</kbd> for new line
          </div>
        </form>
      </div>
    </div>
  )
}


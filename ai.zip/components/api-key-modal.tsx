"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { AlertCircle, CheckCircle2, Key } from "lucide-react"
import { saveApiKey, clearApiKey } from "@/app/actions"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { toast } from "@/components/ui/use-toast"

interface ApiKeyModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: (exists: boolean) => void
  hasExistingKey?: boolean
}

export function ApiKeyModal({ open, onOpenChange, onSuccess, hasExistingKey = false }: ApiKeyModalProps) {
  const [apiKey, setApiKey] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)

    try {
      // Basic client-side validation
      if (!apiKey || apiKey.trim().length < 10) {
        setError("Please enter a valid API key (at least 10 characters)")
        setIsSubmitting(false)
        return
      }

      const result = await saveApiKey(apiKey)

      if (result.success) {
        setSuccess(true)
        setApiKey("")
        toast({
          title: "Success",
          description: "API key saved successfully",
          variant: "default",
        })
        setTimeout(() => {
          onSuccess?.(true)
          onOpenChange(false)
        }, 1500)
      } else {
        setError(result.error || "Failed to save API key")
        toast({
          title: "Error",
          description: result.error || "Failed to save API key",
          variant: "destructive",
        })
      }
    } catch (err: any) {
      const errorMsg = err.message || "An unexpected error occurred"
      setError(errorMsg)
      toast({
        title: "Error",
        description: errorMsg,
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleClearKey = async () => {
    setIsSubmitting(true)
    try {
      await clearApiKey()
      setSuccess(false)
      setApiKey("")
      toast({
        title: "Success",
        description: "API key removed successfully",
      })
      onSuccess?.(false)
      onOpenChange(false)
    } catch (err) {
      setError("Failed to clear API key")
      toast({
        title: "Error",
        description: "Failed to clear API key",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            InfinityAI API Key
          </DialogTitle>
          <DialogDescription>
            Enter your InfinityAI API key to enable AI chat functionality. Your key is stored securely and never exposed
            to the client.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="bg-green-50 text-green-800 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertDescription>API key saved successfully!</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Input
              type="password"
              placeholder="Enter your InfinityAI API key"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              required
              className="font-mono"
            />
            <p className="text-xs text-muted-foreground">
              Contact admin PRAKHAR VARDHAN to get your InfinityAI API key. Only authorized users can access this
              service.
            </p>
          </div>

          <DialogFooter className="flex sm:justify-between gap-2">
            {hasExistingKey && (
              <Button type="button" variant="outline" onClick={handleClearKey} disabled={isSubmitting}>
                Remove Key
              </Button>
            )}
            <div className="flex gap-2">
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button type="submit" disabled={!apiKey || isSubmitting}>
                {isSubmitting ? "Saving..." : "Save API Key"}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}


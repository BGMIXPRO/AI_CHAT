"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ApiKeyModal } from "@/components/api-key-modal"
import { checkApiKeyExists } from "@/app/actions"
import { AlertCircle } from "lucide-react"

interface ApiKeyStatusProps {
  onSuccess?: (exists: boolean) => void
}

export function ApiKeyStatus({ onSuccess }: ApiKeyStatusProps) {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [hasApiKey, setHasApiKey] = useState<boolean | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const checkKey = async () => {
      setIsLoading(true)
      try {
        const { exists } = await checkApiKeyExists()
        setHasApiKey(exists)
        onSuccess?.(exists)
      } catch (error) {
        console.error("Error checking API key:", error)
      } finally {
        setIsLoading(false)
      }
    }

    checkKey()
  }, [onSuccess])

  const handleSuccess = (exists: boolean) => {
    setHasApiKey(exists)
    onSuccess?.(exists)
  }

  return (
    <>
      <Button
        variant={hasApiKey ? "ghost" : "secondary"}
        size="sm"
        className="gap-1.5"
        onClick={() => setIsModalOpen(true)}
      >
        {isLoading ? (
          <span className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-full bg-muted-foreground/30 animate-pulse"></span>
            Checking...
          </span>
        ) : hasApiKey ? (
          <span className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-green-500"></span>
            InfinityAI Connected
          </span>
        ) : (
          <span className="flex items-center gap-1.5">
            <AlertCircle className="h-4 w-4" />
            Add InfinityAI API Key
          </span>
        )}
      </Button>

      <ApiKeyModal
        open={isModalOpen}
        onOpenChange={setIsModalOpen}
        onSuccess={handleSuccess}
        hasExistingKey={hasApiKey || false}
      />
    </>
  )
}


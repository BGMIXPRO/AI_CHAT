"use client"

import type React from "react"

import { useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Send, Loader2 } from "lucide-react"
import TextareaAutosize from "react-textarea-autosize"

interface ChatInputProps {
  input: string
  handleInputChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void
  handleSubmit: (e: React.FormEvent, message?: string) => void
  isLoading: boolean
  disabled?: boolean
  placeholder?: string
}

export function ChatInput({
  input,
  handleInputChange,
  handleSubmit,
  isLoading,
  disabled = false,
  placeholder = "Type your message...",
}: ChatInputProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Focus textarea on mount
  useEffect(() => {
    if (textareaRef.current && !disabled) {
      textareaRef.current.focus()
    }
  }, [disabled])

  // Handle keyboard shortcuts
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      if (input.trim() && !disabled && !isLoading) {
        handleSubmit(e as unknown as React.FormEvent)
      }
    }
  }

  return (
    <form onSubmit={(e) => handleSubmit(e)} className="relative">
      <div className="relative flex items-center">
        <TextareaAutosize
          ref={textareaRef}
          value={input}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled || isLoading}
          className="flex-1 resize-none border rounded-md py-3 px-4 focus-visible:ring-1 focus-visible:ring-ring min-h-[44px] max-h-32"
          minRows={1}
          maxRows={5}
        />
        <Button
          type="submit"
          className="absolute right-1.5 bottom-1.5"
          size="sm"
          disabled={disabled || isLoading || !input.trim()}
        >
          {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </div>
      <div className="text-xs text-muted-foreground mt-1 text-right">
        Press <kbd className="px-1 py-0.5 bg-muted rounded border">Enter</kbd> to send,
        <kbd className="px-1 py-0.5 bg-muted rounded border ml-1">Shift + Enter</kbd> for new line
      </div>
    </form>
  )
}


"use client"

import { useState } from "react"
import type { Message } from "ai"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Copy, ThumbsUp, ThumbsDown, Check } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { formatDistanceToNow } from "date-fns"
import ReactMarkdown from "react-markdown"
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter"
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism"

interface ChatMessageProps {
  message: Message
  isLastMessage: boolean
}

export function ChatMessage({ message, isLastMessage }: ChatMessageProps) {
  const [copied, setCopied] = useState(false)
  const [liked, setLiked] = useState<boolean | null>(null)

  const isUser = message.role === "user"
  const timestamp = message.createdAt ? new Date(message.createdAt) : new Date()

  // Format the timestamp
  const formattedTime = timestamp.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  })

  // Format relative time (e.g., "2 minutes ago")
  const relativeTime = formatDistanceToNow(timestamp, { addSuffix: true })

  // Handle copy to clipboard
  const handleCopy = () => {
    navigator.clipboard.writeText(message.content)
    setCopied(true)
    toast({
      description: "Copied to clipboard",
    })
    setTimeout(() => setCopied(false), 2000)
  }

  // Handle feedback
  const handleFeedback = (isPositive: boolean) => {
    setLiked(isPositive)
    toast({
      description: isPositive ? "Thanks for your feedback!" : "We'll try to improve",
    })
    // In a real app, you would send this feedback to your backend
  }

  return (
    <div className={cn("flex gap-3 max-w-[85%]", isUser ? "ml-auto flex-row-reverse" : "")}>
      {!isUser && (
        <div className="h-8 w-8 rounded-full bg-primary flex-shrink-0 flex items-center justify-center text-primary-foreground font-semibold">
          G
        </div>
      )}

      {isUser && <div className="h-8 w-8 rounded-full bg-muted flex-shrink-0 flex items-center justify-center">U</div>}

      <div className={cn("space-y-2", isUser ? "items-end" : "")}>
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">{isUser ? "You" : "Gemini AI"}</span>
          <span className="text-xs text-muted-foreground" title={relativeTime}>
            {formattedTime}
          </span>
        </div>

        <div className={cn("p-3 rounded-lg", isUser ? "bg-primary text-primary-foreground" : "bg-muted")}>
          <div className="text-sm prose prose-sm dark:prose-invert max-w-none">
            <ReactMarkdown
              components={{
                code({ node, inline, className, children, ...props }) {
                  const match = /language-(\w+)/.exec(className || "")
                  return !inline && match ? (
                    <SyntaxHighlighter language={match[1]} style={vscDarkPlus} PreTag="div" {...props}>
                      {String(children).replace(/\n$/, "")}
                    </SyntaxHighlighter>
                  ) : (
                    <code className={cn("bg-muted px-1 py-0.5 rounded text-sm font-mono", className)} {...props}>
                      {children}
                    </code>
                  )
                },
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
        </div>

        {!isUser && (
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleCopy} title="Copy to clipboard">
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
            <Button
              variant={liked === true ? "secondary" : "ghost"}
              size="icon"
              className="h-7 w-7"
              onClick={() => handleFeedback(true)}
              title="Helpful response"
            >
              <ThumbsUp className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant={liked === false ? "secondary" : "ghost"}
              size="icon"
              className="h-7 w-7"
              onClick={() => handleFeedback(false)}
              title="Unhelpful response"
            >
              <ThumbsDown className="h-3.5 w-3.5" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}


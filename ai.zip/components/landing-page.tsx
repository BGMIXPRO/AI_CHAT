"use client"

import type React from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, MessageSquare, Shield, Zap } from "lucide-react"
import { motion } from "framer-motion"

export function LandingPage({ onStartChat }: { onStartChat: () => void }) {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="relative flex flex-col items-center justify-center py-20 px-4 text-center bg-gradient-to-b from-blue-50 to-purple-50 dark:from-gray-900 dark:to-blue-950">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="absolute inset-0 backdrop-blur-[100px] backdrop-filter"></div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="relative z-10 max-w-4xl mx-auto"
        >
          <div className="mb-6 flex justify-center">
            <Image
              src="/images/infinity-ai-logo.png"
              alt="InfinityAI Logo"
              width={250}
              height={70}
              className="h-auto"
            />
          </div>

          <motion.h1
            className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            Experience the Future of AI Conversation
          </motion.h1>

          <motion.p
            className="text-xl mb-8 max-w-2xl mx-auto text-gray-600 dark:text-gray-300"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            Engage with our advanced AI assistant for intelligent, natural conversations that adapt to your needs.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          >
            <Button
              size="lg"
              onClick={onStartChat}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-6 rounded-full text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Start Chatting Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-white dark:bg-gray-900">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Powerful AI Features</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard
              icon={<MessageSquare className="h-10 w-10 text-blue-500" />}
              title="Natural Conversations"
              description="Experience human-like interactions with our advanced language model."
            />
            <FeatureCard
              icon={<Zap className="h-10 w-10 text-amber-500" />}
              title="Lightning Fast Responses"
              description="Get instant, accurate answers to all your questions."
            />
            <FeatureCard
              icon={<Shield className="h-10 w-10 text-green-500" />}
              title="Secure & Private"
              description="Your conversations are protected with enterprise-grade security."
            />
          </div>

          <div className="text-center mt-12">
            <Button variant="outline" size="lg" onClick={onStartChat} className="rounded-full px-8">
              Try InfinityAI Free
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <motion.div
      className="bg-gray-50 dark:bg-gray-800 p-6 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm hover:shadow-md transition-all duration-300"
      whileHover={{ y: -5 }}
    >
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300">{description}</p>
    </motion.div>
  )
}


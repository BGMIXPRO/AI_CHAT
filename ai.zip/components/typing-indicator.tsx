"use client"

import { cn } from "@/lib/utils"

interface TypingIndicatorProps {
  visible: boolean
  className?: string
}

export function TypingIndicator({ visible, className }: TypingIndicatorProps) {
  if (!visible) return null

  return (
    <div className={cn("flex items-center gap-1 p-2 rounded-lg bg-muted w-16", className)}>
      <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0ms" }} />
      <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "150ms" }} />
      <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "300ms" }} />
    </div>
  )
}


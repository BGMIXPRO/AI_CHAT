"use client"

import { useState } from "react"
import { Settings, Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"

export function UISettings() {
  const [open, setOpen] = useState(false)
  const [fontSize, setFontSize] = useState(16)
  const [bubbleStyle, setBubbleStyle] = useState("rounded")
  const [animations, setAnimations] = useState(true)
  const [typingIndicator, setTypingIndicator] = useState(true)

  const handleSave = () => {
    // In a real app, you would save these settings to localStorage or a database
    localStorage.setItem(
      "uiSettings",
      JSON.stringify({
        fontSize,
        bubbleStyle,
        animations,
        typingIndicator,
      }),
    )

    setOpen(false)
    toast({
      title: "Settings saved",
      description: "Your UI preferences have been updated.",
    })
  }

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setOpen(true)}
        className="rounded-full w-9 h-9 transition-all duration-300 hover:bg-primary/10"
        title="UI Settings"
      >
        <Settings className="h-5 w-5" />
        <span className="sr-only">UI Settings</span>
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>UI Preferences</DialogTitle>
            <DialogDescription>Customize your chat interface appearance and behavior.</DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Message Bubble Style</h4>
              <RadioGroup value={bubbleStyle} onValueChange={setBubbleStyle} className="flex gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="rounded" id="rounded" />
                  <Label htmlFor="rounded" className="cursor-pointer">
                    Rounded
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="square" id="square" />
                  <Label htmlFor="square" className="cursor-pointer">
                    Square
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="gradient" id="gradient" />
                  <Label htmlFor="gradient" className="cursor-pointer">
                    Gradient
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <h4 className="font-medium text-sm">Font Size: {fontSize}px</h4>
              </div>
              <Slider value={[fontSize]} min={12} max={20} step={1} onValueChange={(value) => setFontSize(value[0])} />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium text-sm">Message Animations</h4>
                  <p className="text-xs text-muted-foreground">Enable smooth animations for messages</p>
                </div>
                <Switch checked={animations} onCheckedChange={setAnimations} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium text-sm">Typing Indicator</h4>
                  <p className="text-xs text-muted-foreground">Show when AI is typing</p>
                </div>
                <Switch checked={typingIndicator} onCheckedChange={setTypingIndicator} />
              </div>
            </div>
          </div>

          <DialogFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setOpen(false)}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave}>
              <Check className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}


// Simple encryption/decryption utilities for API key storage
// In production, use a more robust solution with proper key management

export async function encrypt(text: string): Promise<string> {
  try {
    const encoder = new TextEncoder()
    const data = encoder.encode(text)

    // In a real app, you would use a proper encryption key from environment variables
    const key = await generateKey()
    const iv = crypto.getRandomValues(new Uint8Array(12))

    const encryptedData = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, data)

    // Combine IV and encrypted data for storage
    const encryptedArray = new Uint8Array(iv.length + encryptedData.byteLength)
    encryptedArray.set(iv)
    encryptedArray.set(new Uint8Array(encryptedData), iv.length)

    // Convert to base64 for storage
    return btoa(String.fromCharCode(...new Uint8Array(encryptedArray)))
  } catch (error) {
    console.error("Encryption error:", error)
    throw new Error("Failed to encrypt API key")
  }
}

export async function decrypt(encryptedText: string): Promise<string> {
  try {
    // Convert from base64 to array
    const encryptedBytes = atob(encryptedText)
    const encryptedArray = new Uint8Array(encryptedBytes.length)
    for (let i = 0; i < encryptedBytes.length; i++) {
      encryptedArray[i] = encryptedBytes.charCodeAt(i)
    }

    // Extract IV and encrypted data
    const iv = encryptedArray.slice(0, 12)
    const encryptedData = encryptedArray.slice(12)

    const key = await generateKey()

    const decryptedData = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, encryptedData)

    const decoder = new TextDecoder()
    return decoder.decode(decryptedData)
  } catch (error) {
    console.error("Decryption error:", error)
    throw new Error("Invalid API key format or encryption error")
  }
}

// For demo purposes - in production use a proper key derivation
async function generateKey() {
  try {
    // In production, use a proper secret from environment variables
    // This is a fallback for development only
    const secret = process.env.ENCRYPTION_SECRET || "infinity-secure-encryption-key-for-development-only"
    const encoder = new TextEncoder()
    const keyMaterial = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "PBKDF2" }, false, [
      "deriveBits",
      "deriveKey",
    ])

    return crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: encoder.encode("infinity-salt-value"),
        iterations: 100000,
        hash: "SHA-256",
      },
      keyMaterial,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"],
    )
  } catch (error) {
    console.error("Key generation error:", error)
    throw new Error("Failed to generate encryption key")
  }
}

